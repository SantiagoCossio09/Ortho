# OrthoSmile - Consultorio de Ortodoncia

Proyecto académico en React + Vite, sin base de datos. Los datos se guardan en localStorage y son ficticios.

## Estructura por opciones del menú

- `src/pages/Inicio.jsx`
- `src/pages/Agenda.jsx`
- `src/pages/Pacientes.jsx`
- `src/pages/Tratamientos.jsx`
- `src/pages/Procedimientos.jsx`
- `src/pages/Historias.jsx`
- `src/pages/Pagos.jsx`
- `src/pages/Insumos.jsx`
- `src/pages/Proveedores.jsx`
- `src/pages/Profesionales.jsx`
- `src/pages/Usuarios.jsx`
- `src/pages/Reportes.jsx`

Además, `src/pages/Citas.jsx` se usa como gestión detallada desde Agenda.

## Ejecutar

```powershell
npm install
npm run dev
```
