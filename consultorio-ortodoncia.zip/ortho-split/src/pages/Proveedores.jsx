import React from 'react';
import { CrudPage } from '../components/UI';

export default function Proveedores(props) {
  return <CrudPage section="proveedores" {...props} />;
}
