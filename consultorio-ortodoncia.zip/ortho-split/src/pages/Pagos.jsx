import React from 'react';
import { CrudPage } from '../components/UI';

export default function Pagos(props) {
  return <CrudPage section="pagos" {...props} />;
}
