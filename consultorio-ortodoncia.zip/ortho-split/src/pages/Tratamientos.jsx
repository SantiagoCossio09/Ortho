import React from 'react';
import { CrudPage } from '../components/UI';

export default function Tratamientos(props) {
  return <CrudPage section="tratamientos" {...props} />;
}
