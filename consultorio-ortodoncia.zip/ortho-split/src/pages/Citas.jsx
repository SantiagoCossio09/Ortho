import React from 'react';
import { CrudPage } from '../components/UI';

export default function Citas(props) {
  return <CrudPage section="citas" {...props} />;
}
