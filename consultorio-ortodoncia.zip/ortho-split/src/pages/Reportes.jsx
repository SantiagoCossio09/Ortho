import React from 'react';
import { money } from '../data';

const Bar = ({ label, value, max }) => (
  <div className="barrow">
    <span>{label}</span>
    <div>
      <i
        style={{
          width: `${Math.max(5, (value / Math.max(max, 1)) * 100)}%`,
        }}
      />
    </div>
    <b>{value}</b>
  </div>
);

const ReportCard = ({ title, children }) => (
  <div className="card reportcard">
    <h3>{title}</h3>
    {children}
  </div>
);

export default function Reportes({ data }) {
  const total = data.pagos.reduce(
    (a, x) => a + Number(x.monto),
    0
  );

  const paid = data.pagos
    .filter((x) => x.estado === 'Pagado')
    .reduce((a, x) => a + Number(x.monto), 0);

  const active = data.tratamientos.filter(
    (x) => x.estado === 'En curso'
  ).length;

  return (
    <>
      <div className="pagehead">
        <div>
          <span className="eyebrow">ANÁLISIS</span>
          <h1>▥ Reportes y estadísticas</h1>
          <p>
            Información organizada para apoyar la gestión del consultorio.
          </p>
        </div>

      </div>

      <div className="reportcards">
        <ReportCard title="Pacientes por estado">
          <Bar
            label="Activos"
            value={
              data.pacientes.filter(
                (x) => x.estado === 'Activo'
              ).length
            }
            max={data.pacientes.length}
          />
          <Bar
            label="En tratamiento"
            value={
              data.pacientes.filter(
                (x) => x.estado === 'En tratamiento'
              ).length
            }
            max={data.pacientes.length}
          />
          <Bar
            label="Finalizados"
            value={
              data.pacientes.filter(
                (x) => x.estado === 'Finalizado'
              ).length
            }
            max={data.pacientes.length}
          />
        </ReportCard>

        <ReportCard title="Citas por estado">
          <Bar
            label="Confirmadas"
            value={
              data.citas.filter(
                (x) => x.estado === 'Confirmada'
              ).length
            }
            max={data.citas.length}
          />
          <Bar
            label="Pendientes"
            value={
              data.citas.filter(
                (x) => x.estado === 'Pendiente'
              ).length
            }
            max={data.citas.length}
          />
        </ReportCard>

        <ReportCard title="Resumen financiero">
          <div className="bigmoney">{money(paid)}</div>
          <p>Pagos confirmados</p>
          <div className="lineinfo">
            <span>Total registrado</span>
            <b>{money(total)}</b>
          </div>
        </ReportCard>

        <ReportCard title="Tratamientos">
          <div className="bigmoney">{active}</div>
          <p>Tratamientos en curso</p>
          <div className="lineinfo">
            <span>Total</span>
            <b>{data.tratamientos.length}</b>
          </div>
        </ReportCard>
      </div>

      <div className="reportTable card">
        <div className="cardhead">
          <div>
            <h3>Reportes de listados</h3>
            <p>Consultas rápidas del sistema</p>
          </div>
        </div>

        <div className="reportlinks">
          <button>
            Listado de pacientes activos
            <span>
              {
                data.pacientes.filter(
                  (x) => x.estado !== 'Finalizado'
                ).length
              }
            </span>
          </button>

          <button>
            Agenda de citas
            <span>{data.citas.length}</span>
          </button>

          <button>
            Tratamientos en curso
            <span>{active}</span>
          </button>

          <button>
            Pagos pendientes
            <span>
              {
                data.pagos.filter(
                  (x) => x.estado === 'Pendiente'
                ).length
              }
            </span>
          </button>

          <button>
            Insumos bajo stock
            <span>
              {
                data.insumos.filter(
                  (x) => x.stock < x.minimo
                ).length
              }
            </span>
          </button>
        </div>
      </div>
    </>
  );
}
