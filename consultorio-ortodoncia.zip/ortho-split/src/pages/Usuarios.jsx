import React from 'react';
import { CrudPage } from '../components/UI';

export default function Usuarios(props) {
  return <CrudPage section="usuarios" {...props} />;
}
