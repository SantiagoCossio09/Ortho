import React from 'react';
import { CrudPage } from '../components/UI';

export default function Pacientes(props) {
  return <CrudPage section="pacientes" {...props} />;
}
