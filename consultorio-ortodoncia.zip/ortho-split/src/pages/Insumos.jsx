import React from 'react';
import { CrudPage } from '../components/UI';

export default function Insumos(props) {
  return <CrudPage section="insumos" {...props} />;
}
