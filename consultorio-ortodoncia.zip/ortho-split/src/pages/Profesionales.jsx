import React from 'react';
import { CrudPage } from '../components/UI';

export default function Profesionales(props) {
  return <CrudPage section="doctores" {...props} />;
}
