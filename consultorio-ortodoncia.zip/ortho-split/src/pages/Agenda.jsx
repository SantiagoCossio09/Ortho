import React from 'react';
import { CalendarDays, FileText } from 'lucide-react';
import { Status } from '../components/UI';

export default function Agenda({ data, go }) {
  return (
    <>
      <div className="pagehead">
        <div>
          <span className="eyebrow">PROCESO PRINCIPAL</span>
          <h1>
            <CalendarDays size={27} />
            Agenda de citas
          </h1>
          <p>
            Programa y controla las citas de valoración y seguimiento.
          </p>
        </div>

        <button className="primary" onClick={() => go('citas')}>
          ＋ Administrar citas
        </button>
      </div>

      <div className="agendaGrid">
        {['2026-10-07', '2026-10-08', '2026-10-09'].map((date) => (
          <div className="day card" key={date}>
            <div className="dayhead">
              <b>
                {new Date(date + 'T12:00:00').toLocaleDateString('es-CO', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
              </b>
              <span>
                {data.citas.filter((c) => c.fecha === date).length} citas
              </span>
            </div>

            {data.citas
              .filter((c) => c.fecha === date)
              .map((c) => (
                <div className="slot" key={c.id}>
                  <strong>{c.hora}</strong>
                  <div>
                    <b>{c.paciente}</b>
                    <small>{c.motivo}</small>
                  </div>
                  <Status text={c.estado} />
                </div>
              ))}

            {!data.citas.some((c) => c.fecha === date) && (
              <div className="empty">Sin citas</div>
            )}
          </div>
        ))}
      </div>

      <div className="process card">
        <div>
          <h3>Proceso de atención</h3>
          <p>
            1. Agendar → 2. Confirmar → 3. Atender → 4. Registrar historia →
            5. Generar pago
          </p>
        </div>

        <button className="secondary" onClick={() => go('historias')}>
          <FileText size={17} />
          Historias clínicas
        </button>
      </div>
    </>
  );
}
