import React from 'react';
import {
  AlertCircle,
  CalendarDays,
  HeartPulse,
  Users,
  WalletCards,
} from 'lucide-react';
import { money } from '../data';
import { Status } from '../components/UI';

const Stat = ({ title, value, sub, Icon }) => (
  <div className="stat">
    <div className="staticon">
      <Icon size={20} />
    </div>
    <div>
      <span>{title}</span>
      <strong>{value}</strong>
      <small>{sub}</small>
    </div>
  </div>
);

export default function Inicio({ data, go }) {
  const revenue = data.pagos
    .filter((x) => x.estado === 'Pagado')
    .reduce((a, x) => a + Number(x.monto), 0);

  const low = data.insumos.filter((x) => x.stock < x.minimo).length;

  return (
    <>
      <div className="hero">
        <div>
          <span className="eyebrow">PANEL DE CONTROL</span>
          <h1>Buenos días, Admin 👋</h1>
          <p>
            Resumen general del consultorio y actividad de ortodoncia.
          </p>
        </div>

        <button className="primary" onClick={() => go('agenda')}>
          ＋ Agendar cita
        </button>
      </div>

      <div className="stats">
        <Stat
          title="Pacientes activos"
          value={data.pacientes.filter((x) => x.estado !== 'Finalizado').length}
          Icon={Users}
          sub="en tratamiento"
        />
        <Stat
          title="Citas próximas"
          value={data.citas.filter((x) => x.estado !== 'Atendida').length}
          Icon={CalendarDays}
          sub="agenda registrada"
        />
        <Stat
          title="Ingresos registrados"
          value={money(revenue)}
          Icon={WalletCards}
          sub="pagos confirmados"
        />
        <Stat
          title="Alertas de inventario"
          value={low}
          Icon={AlertCircle}
          sub="requieren revisión"
        />
      </div>

      <div className="grid2">
        <div className="card">
          <div className="cardhead">
            <div>
              <h3>Próximas citas</h3>
              <p>Agenda del consultorio</p>
            </div>
            <button className="link" onClick={() => go('agenda')}>
              Ver agenda
            </button>
          </div>

          {data.citas.slice(0, 4).map((c) => (
            <div className="appointment" key={c.id}>
              <div className="datebox">
                <b>{c.fecha.slice(8)}</b>
                <span>OCT</span>
              </div>
              <div>
                <b>{c.paciente}</b>
                <p>
                  {c.hora} · {c.motivo}
                </p>
              </div>
              <Status text={c.estado} />
            </div>
          ))}
        </div>

        <div className="card">
          <div className="cardhead">
            <div>
              <h3>Estado del tratamiento</h3>
              <p>Seguimiento de pacientes</p>
            </div>
          </div>

          {data.tratamientos.map((t) => (
            <div className="progressrow" key={t.id}>
              <div>
                <b>{t.paciente}</b>
                <span>{t.tipo}</span>
              </div>
              <div className="progress">
                <i
                  style={{
                    width:
                      t.estado === 'Finalizado'
                        ? '100%'
                        : t.id === 1
                          ? '58%'
                          : '74%',
                  }}
                />
              </div>
              <small>{t.estado}</small>
            </div>
          ))}
        </div>
      </div>

      <div className="quick">
        <button onClick={() => go('pacientes')}>
          <Users />
          Gestionar pacientes
        </button>
        <button onClick={() => go('tratamientos')}>
          <HeartPulse />
          Tratamientos
        </button>
        <button onClick={() => go('pagos')}>
          <WalletCards />
          Registrar pago
        </button>
        <button onClick={() => go('reportes')}>▥ Ver reportes</button>
      </div>
    </>
  );
}
