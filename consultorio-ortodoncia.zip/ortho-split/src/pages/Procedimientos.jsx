import React from 'react';
import { CrudPage } from '../components/UI';

export default function Procedimientos(props) {
  return <CrudPage section="procedimientos" {...props} />;
}
