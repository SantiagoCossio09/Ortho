import React from 'react';
import { CrudPage } from '../components/UI';

export default function Historias(props) {
  return <CrudPage section="historias" {...props} />;
}
