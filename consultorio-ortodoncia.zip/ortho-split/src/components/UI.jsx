import React from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Edit3,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { meta, money } from '../data';

export function Status({ text }) {
  return (
    <span
      className={
        'status ' + String(text).toLowerCase().replaceAll(' ', '-')
      }
    >
      {text}
    </span>
  );
}

export function CrudPage({
  section,
  data,
  query,
  setQuery,
  page,
  setPage,
  onAdd,
  onEdit,
  onDelete,
}) {
  const m = meta[section];
  const rows = data[section] || [];

  const filtered = rows.filter((r) =>
    m.fields.some(([k]) =>
      String(r[k] ?? '')
        .toLowerCase()
        .includes(query.toLowerCase())
    )
  );

  const per = 6;
  const total = Math.max(1, Math.ceil(filtered.length / per));
  const shown = filtered.slice((page - 1) * per, page * per);

  return (
    <>
      <div className="pagehead">
        <div>
          <span className="eyebrow">GESTIÓN</span>
          <h1>{m.label}</h1>
          <p>
            Administra, consulta, edita y elimina registros del consultorio.
          </p>
        </div>

        <button className="primary" onClick={onAdd}>
          ＋ Nuevo registro
        </button>
      </div>

      <div className="toolbar">
        <div className="search">
          <Search size={17} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Buscar en ${m.label.toLowerCase()}...`}
          />
        </div>
        <span className="count">{filtered.length} registros</span>
      </div>

      <div className="tablecard">
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                {m.fields.map(([k, l]) => (
                  <th key={k}>{l}</th>
                ))}
                <th>Acciones</th>
              </tr>
            </thead>

            <tbody>
              {shown.length ? (
                shown.map((r) => (
                  <tr key={r.id}>
                    {m.fields.map(([k]) => (
                      <td key={k}>
                        {['monto', 'costo', 'precio'].includes(k)
                          ? money(r[k])
                          : k === 'estado'
                            ? <Status text={r[k]} />
                            : r[k]}
                      </td>
                    ))}
                    <td>
                      <div className="actions">
                        <button onClick={() => onEdit(r)}>
                          <Edit3 size={15} />
                        </button>
                        <button
                          className="danger"
                          onClick={() => onDelete(r.id)}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={m.fields.length + 1}
                    className="empty"
                  >
                    No se encontraron registros.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span>
            Mostrando {shown.length} de {filtered.length}
          </span>
          <div>
            <button
              disabled={page === 1}
              onClick={() => setPage(page - 1)}
            >
              <ChevronLeft />
            </button>
            <b>
              {page} / {total}
            </b>
            <button
              disabled={page === total}
              onClick={() => setPage(page + 1)}
            >
              <ChevronRight />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export function Modal({ modal, onClose, onSave }) {
  const m = meta[modal.key];

  const [form, setForm] = React.useState(
    modal.row ||
      Object.fromEntries(
        m.fields.map(([k]) => [
          k,
          k === 'fecha' || k === 'inicio'
            ? '2026-10-06'
            : k === 'estado'
              ? 'Activo'
              : ['monto', 'costo', 'precio', 'stock', 'minimo'].includes(k)
                ? '0'
                : '',
        ])
      )
  );

  const set = (k, v) =>
    setForm((f) => ({
      ...f,
      [k]: v,
    }));

  const submit = (e) => {
    e.preventDefault();

    if (
      m.fields.some(
        ([k]) => !String(form[k] ?? '').trim()
      )
    ) {
      return alert('Completa todos los campos.');
    }

    onSave(modal.key, form);
  };

  return (
    <div className="overlay">
      <div className="modal">
        <div className="modalhead">
          <div>
            <span className="eyebrow">FORMULARIO</span>
            <h2>
              {modal.row ? 'Editar' : 'Nuevo'} {m.label}
            </h2>
          </div>
          <button onClick={onClose}>
            <X />
          </button>
        </div>

        <form onSubmit={submit}>
          <div className="formgrid">
            {m.fields.map(([k, l]) => (
              <label key={k}>
                {l}
                <input
                  value={form[k] ?? ''}
                  type={
                    k === 'fecha' || k === 'inicio'
                      ? 'date'
                      : ['monto', 'costo', 'precio', 'stock', 'minimo'].includes(k)
                        ? 'number'
                        : k === 'hora'
                          ? 'time'
                          : 'text'
                  }
                  onChange={(e) => set(k, e.target.value)}
                />
              </label>
            ))}
          </div>

          <div className="modalactions">
            <button
              type="button"
              className="secondary"
              onClick={onClose}
            >
              Cancelar
            </button>
            <button className="primary" type="submit">
              <CheckCircle2 size={17} />
              Guardar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
