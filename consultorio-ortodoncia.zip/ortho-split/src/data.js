export const seed = {
  "pacientes": [
    {
      "id": 1,
      "nombre": "Valentina Ríos",
      "doc": "CC 1023456789",
      "telefono": "300 555 1201",
      "email": "valentina.rios@demo.com",
      "fecha": "2005-04-12",
      "estado": "Activo"
    },
    {
      "id": 2,
      "nombre": "Mateo Córdoba",
      "doc": "TI 1002345678",
      "telefono": "301 555 2314",
      "email": "mateo.cordoba@demo.com",
      "fecha": "2008-09-21",
      "estado": "Activo"
    },
    {
      "id": 3,
      "nombre": "Laura Palacios",
      "doc": "CC 1098765432",
      "telefono": "315 555 9044",
      "email": "laura.palacios@demo.com",
      "fecha": "1999-11-03",
      "estado": "En tratamiento"
    },
    {
      "id": 4,
      "nombre": "Samuel Mosquera",
      "doc": "TI 1019988776",
      "telefono": "320 555 6712",
      "email": "samuel.mosquera@demo.com",
      "fecha": "2010-02-17",
      "estado": "Activo"
    },
    {
      "id": 5,
      "nombre": "Daniela Mena",
      "doc": "CC 1087654321",
      "telefono": "312 555 8830",
      "email": "daniela.mena@demo.com",
      "fecha": "2001-07-26",
      "estado": "Finalizado"
    }
  ],
  "doctores": [
    {
      "id": 1,
      "nombre": "Dra. Camila Torres",
      "especialidad": "Ortodoncia",
      "telefono": "310 555 1010",
      "email": "camila.torres@demo.com",
      "estado": "Activo"
    },
    {
      "id": 2,
      "nombre": "Dr. Andrés Palacios",
      "especialidad": "Rehabilitación oral",
      "telefono": "316 555 2020",
      "email": "andres.palacios@demo.com",
      "estado": "Activo"
    }
  ],
  "citas": [
    {
      "id": 1,
      "paciente": "Valentina Ríos",
      "doctor": "Dra. Camila Torres",
      "fecha": "2026-10-07",
      "hora": "09:00",
      "motivo": "Control de brackets",
      "estado": "Confirmada"
    },
    {
      "id": 2,
      "paciente": "Mateo Córdoba",
      "doctor": "Dra. Camila Torres",
      "fecha": "2026-10-07",
      "hora": "10:30",
      "motivo": "Valoración inicial",
      "estado": "Pendiente"
    },
    {
      "id": 3,
      "paciente": "Laura Palacios",
      "doctor": "Dr. Andrés Palacios",
      "fecha": "2026-10-08",
      "hora": "14:00",
      "motivo": "Retenedor",
      "estado": "Confirmada"
    },
    {
      "id": 4,
      "paciente": "Samuel Mosquera",
      "doctor": "Dra. Camila Torres",
      "fecha": "2026-10-09",
      "hora": "08:30",
      "motivo": "Ajuste mensual",
      "estado": "Pendiente"
    }
  ],
  "tratamientos": [
    {
      "id": 1,
      "paciente": "Valentina Ríos",
      "tipo": "Brackets metálicos",
      "inicio": "2026-02-05",
      "duracion": "18 meses",
      "estado": "En curso",
      "costo": 2400000
    },
    {
      "id": 2,
      "paciente": "Laura Palacios",
      "tipo": "Alineadores transparentes",
      "inicio": "2025-08-18",
      "duracion": "14 meses",
      "estado": "En curso",
      "costo": 3900000
    },
    {
      "id": 3,
      "paciente": "Daniela Mena",
      "tipo": "Retenedores",
      "inicio": "2025-02-10",
      "duracion": "12 meses",
      "estado": "Finalizado",
      "costo": 800000
    }
  ],
  "procedimientos": [
    {
      "id": 1,
      "nombre": "Valoración ortodóntica",
      "categoria": "Diagnóstico",
      "precio": 80000,
      "estado": "Disponible"
    },
    {
      "id": 2,
      "nombre": "Control y ajuste",
      "categoria": "Ortodoncia",
      "precio": 60000,
      "estado": "Disponible"
    },
    {
      "id": 3,
      "nombre": "Instalación de brackets",
      "categoria": "Ortodoncia",
      "precio": 450000,
      "estado": "Disponible"
    },
    {
      "id": 4,
      "nombre": "Blanqueamiento",
      "categoria": "Estética",
      "precio": 280000,
      "estado": "Disponible"
    }
  ],
  "historias": [
    {
      "id": 1,
      "paciente": "Valentina Ríos",
      "fecha": "2026-10-01",
      "diagnostico": "Maloclusión clase II",
      "observacion": "Buena evolución, mantener elásticos.",
      "doctor": "Dra. Camila Torres"
    },
    {
      "id": 2,
      "paciente": "Laura Palacios",
      "fecha": "2026-09-28",
      "diagnostico": "Apiñamiento leve",
      "observacion": "Se entrega nuevo juego de alineadores.",
      "doctor": "Dr. Andrés Palacios"
    }
  ],
  "pagos": [
    {
      "id": 1,
      "paciente": "Valentina Ríos",
      "concepto": "Plan de ortodoncia",
      "fecha": "2026-10-01",
      "monto": 400000,
      "metodo": "Transferencia",
      "estado": "Pagado"
    },
    {
      "id": 2,
      "paciente": "Laura Palacios",
      "concepto": "Cuota mensual",
      "fecha": "2026-09-30",
      "monto": 300000,
      "metodo": "Tarjeta",
      "estado": "Pagado"
    },
    {
      "id": 3,
      "paciente": "Mateo Córdoba",
      "concepto": "Valoración",
      "fecha": "2026-10-03",
      "monto": 80000,
      "metodo": "Efectivo",
      "estado": "Pendiente"
    }
  ],
  "insumos": [
    {
      "id": 1,
      "nombre": "Arcos NiTi 0.016",
      "categoria": "Ortodoncia",
      "stock": 18,
      "minimo": 10,
      "unidad": "Unidad",
      "estado": "Disponible"
    },
    {
      "id": 2,
      "nombre": "Brackets metálicos",
      "categoria": "Brackets",
      "stock": 8,
      "minimo": 12,
      "unidad": "Kit",
      "estado": "Bajo stock"
    },
    {
      "id": 3,
      "nombre": "Guantes de examen",
      "categoria": "Bioseguridad",
      "stock": 120,
      "minimo": 50,
      "unidad": "Caja",
      "estado": "Disponible"
    }
  ],
  "proveedores": [
    {
      "id": 1,
      "nombre": "DentalPro Colombia",
      "contacto": "Mariana López",
      "telefono": "601 555 1001",
      "email": "ventas@dentalpro.demo",
      "estado": "Activo"
    },
    {
      "id": 2,
      "nombre": "OrthoSupply",
      "contacto": "Julián Rivas",
      "telefono": "601 555 1002",
      "email": "contacto@orthosupply.demo",
      "estado": "Activo"
    }
  ],
  "usuarios": [
    {
      "id": 1,
      "nombre": "Administrador Demo",
      "usuario": "admin",
      "rol": "Administrador",
      "estado": "Activo"
    },
    {
      "id": 2,
      "nombre": "Recepción Demo",
      "usuario": "recepcion",
      "rol": "Recepción",
      "estado": "Activo"
    },
    {
      "id": 3,
      "nombre": "Dra. Camila Torres",
      "usuario": "doctora",
      "rol": "Profesional",
      "estado": "Activo"
    }
  ]
};

export const meta = {
  "pacientes": {
    "label": "Pacientes",
    "fields": [
      [
        "nombre",
        "Nombre completo"
      ],
      [
        "doc",
        "Documento"
      ],
      [
        "telefono",
        "Teléfono"
      ],
      [
        "email",
        "Correo"
      ],
      [
        "fecha",
        "Fecha de nacimiento"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "doctores": {
    "label": "Profesionales",
    "fields": [
      [
        "nombre",
        "Nombre"
      ],
      [
        "especialidad",
        "Especialidad"
      ],
      [
        "telefono",
        "Teléfono"
      ],
      [
        "email",
        "Correo"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "citas": {
    "label": "Citas",
    "fields": [
      [
        "paciente",
        "Paciente"
      ],
      [
        "doctor",
        "Profesional"
      ],
      [
        "fecha",
        "Fecha"
      ],
      [
        "hora",
        "Hora"
      ],
      [
        "motivo",
        "Motivo"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "tratamientos": {
    "label": "Tratamientos",
    "fields": [
      [
        "paciente",
        "Paciente"
      ],
      [
        "tipo",
        "Tratamiento"
      ],
      [
        "inicio",
        "Inicio"
      ],
      [
        "duracion",
        "Duración"
      ],
      [
        "estado",
        "Estado"
      ],
      [
        "costo",
        "Costo"
      ]
    ]
  },
  "procedimientos": {
    "label": "Procedimientos",
    "fields": [
      [
        "nombre",
        "Procedimiento"
      ],
      [
        "categoria",
        "Categoría"
      ],
      [
        "precio",
        "Precio"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "historias": {
    "label": "Historias clínicas",
    "fields": [
      [
        "paciente",
        "Paciente"
      ],
      [
        "fecha",
        "Fecha"
      ],
      [
        "diagnostico",
        "Diagnóstico"
      ],
      [
        "observacion",
        "Observación"
      ],
      [
        "doctor",
        "Profesional"
      ]
    ]
  },
  "pagos": {
    "label": "Pagos",
    "fields": [
      [
        "paciente",
        "Paciente"
      ],
      [
        "concepto",
        "Concepto"
      ],
      [
        "fecha",
        "Fecha"
      ],
      [
        "monto",
        "Monto"
      ],
      [
        "metodo",
        "Método"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "insumos": {
    "label": "Insumos",
    "fields": [
      [
        "nombre",
        "Insumo"
      ],
      [
        "categoria",
        "Categoría"
      ],
      [
        "stock",
        "Stock"
      ],
      [
        "minimo",
        "Mínimo"
      ],
      [
        "unidad",
        "Unidad"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "proveedores": {
    "label": "Proveedores",
    "fields": [
      [
        "nombre",
        "Proveedor"
      ],
      [
        "contacto",
        "Contacto"
      ],
      [
        "telefono",
        "Teléfono"
      ],
      [
        "email",
        "Correo"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  },
  "usuarios": {
    "label": "Usuarios",
    "fields": [
      [
        "nombre",
        "Nombre"
      ],
      [
        "usuario",
        "Usuario"
      ],
      [
        "rol",
        "Rol"
      ],
      [
        "estado",
        "Estado"
      ]
    ]
  }
};

export const money = (n) =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0,
  }).format(Number(n) || 0);
