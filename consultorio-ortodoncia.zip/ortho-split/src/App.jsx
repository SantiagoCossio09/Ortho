import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Boxes,
  BriefcaseMedical,
  CalendarDays,
  ClipboardList,
  FileText,
  HeartPulse,
  LayoutDashboard,
  Menu,
  ShieldCheck,
  Stethoscope,
  Users,
  WalletCards,
} from 'lucide-react';
import './index.css';
import { seed } from './data';
import Inicio from './pages/Inicio';
import Agenda from './pages/Agenda';
import Pacientes from './pages/Pacientes';
import Tratamientos from './pages/Tratamientos';
import Procedimientos from './pages/Procedimientos';
import Historias from './pages/Historias';
import Pagos from './pages/Pagos';
import Insumos from './pages/Insumos';
import Proveedores from './pages/Proveedores';
import Profesionales from './pages/Profesionales';
import Usuarios from './pages/Usuarios';
import Reportes from './pages/Reportes';
import Citas from './pages/Citas';
import { Modal } from './components/UI';

const pages = {
  pacientes: Pacientes,
  tratamientos: Tratamientos,
  procedimientos: Procedimientos,
  historias: Historias,
  pagos: Pagos,
  insumos: Insumos,
  proveedores: Proveedores,
  doctores: Profesionales,
  usuarios: Usuarios,
  citas: Citas,
};

const nav = [
  ['dashboard', 'Inicio', LayoutDashboard],
  ['agenda', 'Agenda', CalendarDays],
  ['pacientes', 'Pacientes', Users],
  ['tratamientos', 'Tratamientos', HeartPulse],
  ['procedimientos', 'Procedimientos', ClipboardList],
  ['historias', 'Historias', FileText],
  ['pagos', 'Pagos', WalletCards],
  ['insumos', 'Insumos', Boxes],
  ['proveedores', 'Proveedores', BriefcaseMedical],
  ['doctores', 'Profesionales', Stethoscope],
  ['usuarios', 'Usuarios', ShieldCheck],
  ['reportes', 'Reportes', BarChart3],
];

const load = () => {
  try {
    return JSON.parse(localStorage.getItem('orthosmiledemo')) || seed;
  } catch {
    return seed;
  }
};

export default function App() {
  const [data, setData] = useState(load);
  const [section, setSection] = useState('dashboard');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState(null);
  const [mobile, setMobile] = useState(false);

  useEffect(() => {
    localStorage.setItem('orthosmiledemo', JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    setPage(1);
  }, [section, query]);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 2600);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const go = (s) => {
    setSection(s);
    setMobile(false);
  };

  const remove = (key, id) => {
    if (!confirm('¿Deseas eliminar este registro?')) return;

    setData((d) => ({
      ...d,
      [key]: d[key].filter((x) => x.id !== id),
    }));

    setToast('Registro eliminado correctamente.');
  };

  const save = (key, obj) => {
    setData((d) => {
      const arr = obj.id
        ? d[key].map((x) => (x.id === obj.id ? obj : x))
        : [...d[key], { ...obj, id: Date.now() }];

      return { ...d, [key]: arr };
    });

    setModal(null);
    setToast(obj.id ? 'Registro actualizado.' : 'Registro creado correctamente.');
  };

  const Page = pages[section];

  const common = {
    data,
    query,
    setQuery,
    page,
    setPage,
    onAdd: () => setModal({ key: section }),
    onEdit: (r) => setModal({ key: section, row: r }),
    onDelete: (id) => remove(section, id),
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brandmark">
            <HeartPulse size={24} />
          </div>
          <div>
            <b>OrthoSmile</b>
            <span>Consultorio de Ortodoncia</span>
          </div>
        </div>

        <button
          className="mobileBtn"
          onClick={() => setMobile(!mobile)}
        >
          <Menu />
        </button>

        <nav className={mobile ? 'nav open' : 'nav'}>
          {nav.map(([id, label, Icon]) => (
            <button
              key={id}
              className={section === id ? 'active' : ''}
              onClick={() => go(id)}
            >
              <Icon size={16} />
              <span>{label}</span>
            </button>
          ))}
        </nav>

      </header>

      <main className="content">
        {section === 'dashboard' ? (
          <Inicio data={data} go={go} />
        ) : section === 'agenda' ? (
          <Agenda data={data} go={go} />
        ) : section === 'reportes' ? (
          <Reportes data={data} />
        ) : Page ? (
          <Page {...common} />
        ) : null}
      </main>

      {modal && (
        <Modal
          modal={modal}
          onClose={() => setModal(null)}
          onSave={save}
        />
      )}

      {toast && <div className="toast success">✓ {toast}</div>}

      <footer>
        OrthoSmile · Sistema académico de demostración · Todos los datos son
        ficticios
      </footer>
    </div>
  );
}
